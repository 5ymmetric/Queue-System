package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
@Controller
@RequestMapping("/users")
public class MultipleUsersController {

    @Autowired
    private UserService userService;

    @GetMapping(value = "/all/TA")
    public String showAllTA(Model model) {
        List<User> realUsers = new ArrayList<User>();
        for(User user: userService.findAll()){
            if(!(user.getUsername().equals("") || user.getPassword().equals(""))){
                realUsers.add(user);
            }
        }
        model.addAttribute("users", realUsers);

        return "allBooksTA";
    }

    @GetMapping(value = "/all")
    public String showAll(Model model) {
        List<User> realUsers = new ArrayList<User>();
        for(User user: userService.findAll()){
            if(!(user.getUsername().equals("") || user.getPassword().equals(""))){
                realUsers.add(user);
            }
        }
        model.addAttribute("users", realUsers);

        return "allBooks";
    }

    @GetMapping(value = "/create")
    public String showCreateForm(Model model) {
        UserCreationDto usersForm = new UserCreationDto();
        usersForm.addUser(new User());

        model.addAttribute("form", usersForm);

        return "createBooksForm";
    }

    @GetMapping(value = "/edit")
    public String showEditForm(Model model) {
        List<User> books = new ArrayList<>();

        List<User> realUsers = new ArrayList<User>();
        for(User user: userService.findAll()){
            if(!(user.getUsername().equals("") || user.getPassword().equals(""))){
                realUsers.add(user);
            }
        }

        realUsers.iterator().forEachRemaining(books::add);

        model.addAttribute("form", new UserCreationDto(books));

        return "editBooksForm";
    }


    @PostMapping(value = "/save")
    public String saveBooks(@ModelAttribute UserCreationDto form, Model model) {
        userService.saveAll(form.getUsers());

        List<User> realUsers = new ArrayList<User>();
        for(User user: userService.findAll()){
            if(!(user.getUsername().equals("") || user.getPassword().equals(""))){
                realUsers.add(user);
            }
        }

        model.addAttribute("books", realUsers);
        System.out.println(realUsers);
        return "redirect:/users/all";
    }
}
