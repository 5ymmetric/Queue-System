package com.example.demo.ToolBox;

import java.util.Base64;

public class Base64Cipher implements Cipher {

    @Override
    public String encipher(String plaintext) {
        try {
            String cipherText = Base64.getEncoder().encodeToString(plaintext.getBytes());
            return cipherText;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public String decipher(String ciphertext) {
        try {
            String decipherText = new String(Base64.getDecoder().decode(ciphertext));
            return decipherText;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}

