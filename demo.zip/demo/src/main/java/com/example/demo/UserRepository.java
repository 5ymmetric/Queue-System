//package com.example.demo;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.jdbc.core.BeanPropertyRowMapper;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.core.RowMapper;
//import org.springframework.stereotype.Repository;
//
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.List;
//
//@Repository
//public class UserRepository {
//
//    @Autowired
//    JdbcTemplate jdbcTemplate;
//
//
//    class UserRowMapper implements RowMapper<User> {
//        @Override
//        public User mapRow(ResultSet rs, int rowNum) throws SQLException {
//            User user = new User();
//            user.setUsername(rs.getString("first_name"));
//            user.setPassword(rs.getString("password"));
//            return user;
//        }
//
//    }
//
//    public User findByPassword(String password){
//        String query = "SELECT * FROM Users WHERE password=?";
//        User user = jdbcTemplate.queryForObject(query,new Object[]{password},new BeanPropertyRowMapper<>(User.class));
//
//        return user;
//    }
//
//    public List<User> findAll() {
//        return jdbcTemplate.query("select * from Users", new UserRowMapper());
//    }
//}
