package com.example.demo;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class InMemoryUserService implements UserService {

    static Map<Long, User> usersDB = new HashMap<>();

    @Override
    public List<User> findAll() {
        return new ArrayList<>(usersDB.values());
    }

    @Override
    public void saveAll(List<User> users) {
        long nextId = getNextId();
        for (User user : users) {
            if (user.getId() == 0) {
                user.setId(nextId++);
            }
        }

        Map<Long, User> userMap = users.stream()
                .collect(Collectors.toMap(User::getId, Function.identity()));

        usersDB.putAll(userMap);
    }

    private Long getNextId() {
        return usersDB.keySet()
                .stream()
                .mapToLong(value -> value)
                .max()
                .orElse(0) + 1;
    }
}
