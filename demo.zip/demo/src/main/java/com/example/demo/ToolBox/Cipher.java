package com.example.demo.ToolBox;


public interface Cipher {
    String encipher(String plaintext);//encode

    String decipher(String ciphertext);//decode
}

