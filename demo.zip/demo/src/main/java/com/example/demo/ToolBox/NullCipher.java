package com.example.demo.ToolBox;

public class NullCipher implements Cipher {
    @Override
    public String encipher(String plaintext) {
        return plaintext;
    }

    @Override
    public String decipher(String ciphertext) {
        return ciphertext;
    }
}

