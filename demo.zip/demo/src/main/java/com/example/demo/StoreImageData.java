package com.example.demo;

import org.hibernate.*;

import javax.websocket.Session;
import java.io.*;
import java.lang.module.Configuration;

public class StoreImageData
{
    public static void main(String arg[])throws IOException
    {
        Session session=new Configuration().configure("imageData.cfg.xml")
                .buildSessionFactory().openSession();

        Transaction tx=session.beginTransaction();
        File imagePath = new File("C:/Users/Karthik.P/Downloads/cat.jpeg"); //here we given fully specified image path.

        byte[] imageInBytes = new byte[(int)imagePath.length()]; //image convert in byte form
        FileInputStream inputStream = new FileInputStream(imagePath);  //input stream object create to read the file
        inputStream.read(imageInBytes); // here inputstream object read the file
        inputStream.close();

        MyImageBean object1 = new MyImageBean();
        object1.setImageName( "Fruits Image" );
        object1.setImage( imageInBytes );

        session.save(object1);
        tx.commit();
        System.out.println("Image Data Saved Successfully in Database..");
        session.close();
    }
}

