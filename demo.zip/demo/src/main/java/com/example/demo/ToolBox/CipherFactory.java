package com.example.demo.ToolBox;

import java.util.Scanner;

public class CipherFactory {
    public static NullCipher createCipher() {
        return new NullCipher();
    }

    //keys: message passed in
    public static Cipher createCipher(int name, String[] keys) {
        //create and return an instance of a Cipher implementation class that corresponds to *name*
        switch (name) {
            case 1:
                return new Base64Cipher();
            case 2:
                return new MorseCipher();
            case 3:
                return new NullCipher();
            default:
                System.out.println("please choose a valid option!");
                Scanner s = new Scanner(System.in);
                return createCipher(s.nextInt(), keys);
        }
    }


}
