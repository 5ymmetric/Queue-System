//package com.example.demo;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@Controller
//public class LoginController {
//    BookService bookService = new InMemoryBookService();
//    @GetMapping("/all")
//    public String showAll(Model model) {
//        model.addAttribute("books", bookService.findAll());
//        return "books/allBooks";
//    }
//
//    @GetMapping("/create")
//    public String showCreateForm(Model model) {
//        BookCreationDto booksForm = new BookCreationDto();
//
//        for (int i = 1; i <= 3; i++) {
//            booksForm.addBook(new Book());
//        }
//
//        model.addAttribute("form", booksForm);
//        return "books/createBooksForm";
//    }
//
//    @PostMapping("/save")
//    public String saveBooks(@ModelAttribute BookCreationDto form, Model model) {
//        bookService.saveAll(form.getBooks());
//
//        model.addAttribute("books", bookService.findAll());
//        return "redirect:/books/all";
//    }
//
//    @GetMapping("/edit")
//    public String showEditForm(Model model) {
//        List<Book> books = new ArrayList<>();
//        bookService.findAll().iterator().forEachRemaining(books::add);
//
//        model.addAttribute("form", new BookCreationDto(books));
//        return "books/editBooksForm";
//    }
//
//    }
//
