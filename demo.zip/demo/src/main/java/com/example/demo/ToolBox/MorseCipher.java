package com.example.demo.ToolBox;


import java.util.Scanner;

public class MorseCipher implements Cipher{
    private static final String[] Letters = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
    private static final String[] MorseCode = {".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---",
            ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--.."};


    private String MosrseCipher(String[] given) {
        Scanner s;
        String output = "";
        try {
            for (int i = 0; i < given.length; i++) {
                for (int j = 0; j < Letters.length; j++) {
                    if (given[i].equalsIgnoreCase(Letters[j])) {
                        output += (MorseCode[j]);
                    }
                }
            }
            if (output.isEmpty()) {
                System.out.println("please enter nonempty prompt:\n");
                s = new Scanner(System.in);
                MosrseCipher(s.nextLine().split(""));
            }
            System.out.println("Morse output: " + output);
            return output;
        } catch (Exception e) {
            System.out.println("cannot translate it to mosrse, please enter another text only with letters:\n");
            s = new Scanner(System.in);
            MosrseCipher(s.nextLine().split(""));
        }
        return null;
    }

    private String MosrseDeciper(String given) {
        String output = "";
        try {
            for (int i = 0; i < given.length(); i++) {
                for (int j = 0; j < MorseCode.length; j++) {
                    if (given.charAt(i) == MorseCode[j].toCharArray()[0]) {
                        output += (MorseCode[j]);
                    }
                }
            }
            System.out.println("Morse decipher output: " + output);
            return output;
        } catch (Exception e) {
            new Base64Cipher().decipher(given);
        }
        return null;
    }

    @Override
    public String encipher(String plaintext) {
        return MosrseCipher(plaintext.split(""));
    }

    @Override
    public String decipher(String ciphertext) {
        return MosrseDeciper(ciphertext);
    }

}
